import { View, Text } from 'react-native'
import React from 'react'

const ActivityIndicatorScreen = () => {
  return (
    <View>
      <Text>ActivityIndicatorScreen</Text>
    </View>
  )
}

export default ActivityIndicatorScreen