import React from 'react'
import { View, Text,TouchableOpacity,TextInput,StyleSheet,Button, ScrollView, Image } from 'react-native'
import { Appbar } from "react-native-paper";
import StarReview from 'react-native-star-review';
import Ionicons from 'react-native-vector-icons/dist/Ionicons';
import AppConstance,{deviceHeight,deviceWidth} from "../constance/AppConstance"

const TrackYourDelivery = ({navigation}) => {
  return (
    <View>
      <Appbar.Header style={styles.header}>

        <View style={styles.headview}>
          <View style={{justifyContent:"center"}}>
            <Ionicons name='chevron-back' onPress={()=> {navigation.goBack()}} color={'grey'} style={{alignSelf:'center'}} size={25}/>
            </View>
          <Text style={{color:"black",fontSize:16,alignSelf:'center'}}>Track Your Load</Text>
          <View>
            </View>
        </View>

      </Appbar.Header>

    <ScrollView>
      <View style={styles.mapShow}>
        
      <Text style={{color:"black",fontSize:15,alignSelf:"center"}}>Maps</Text>
      <Image  style={{width:"100%",height:250}} source={require('../assets/MapPic.png')} />
    <View style={{marginTop:170}}>
    
      </View>
     
      </View>



<View style={{paddingHorizontal:20, width:'100%'}}>


<TouchableOpacity style={{width:'90%',marginTop:10, borderWidth:1.2, borderRadius:15,borderColor:'#EFDF79', height:80,alignSelf:'center', flexDirection:'row'}}>
<View style={{  padding:"2%", width: "25%", height: "100%" }}>
            <Image source={require('../assets/bk.png')}  style={{width:"100%",borderRadius:400/2, height:"100%"}} />
          </View>

  <View style={{height:'100%', width:'75%', }}>
    <View style={{height:'30%',width:'100%', justifyContent:'flex-end', }}>
      <View style={{borderRadius:10,height:'100%', alignSelf:'flex-end',backgroundColor:'black', paddingHorizontal:'8%', borderRadius:10,borderColor:'#EFDF79', borderWidth:2}}>
        <Text style={{color:'#EFDF79'}}>Accepted</Text>
      </View>
    </View>

    <View style={{height:'75%',justifyContent:'center', paddingHorizontal:'5%'}}>
      <Text style={{alignSelf:'center'}}>Driver Name</Text>
      <StarReview 
       ratings={2}
       stars={5}
       starColor="#EFDF79"
    
     />
    </View>
  </View>

  </TouchableOpacity>

  <View style={styles.btnDelivered}
    
    // onPress={() => navigation.navigate('')}
   >
     <Text style={{color:"black"}}>
      DOT Number
</Text>
  </View>
  <View style={styles.btnDelivered}
    
    // onPress={() => navigation.navigate('')}
   >
     <Text style={{color:"black"}}> MC Number
</Text>
  </View>
  <View style={styles.btnDelivered}
    
    // onPress={() => navigation.navigate('')}
   >
     <Text style={{color:"black"}}>
      Caution:
     1- Driving can drive 11 hours a day
     2- Once the Load is Confirmed and pickup the load cannot be cancel
</Text>
  </View>
</View>

  </ScrollView>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
      flex: 1,
    //   justifyContent: center,
    marginTop: 170,
      padding: 24,
      backgroundColor: "#eaeaea"
    },
    btnDelivered:{
      width:"90%",
      marginTop:10,
      alignSelf:"center",
      alignItems:"center",
      borderRadius:15,
      padding:20,
      borderWidth:1.2,
     borderColor:'#EFDF79',
      alignContent:"center"
    },
  input: {
    height: 40,
    width:'60%',
    margin: 12,
    borderWidth: 1,
    padding: 10,
    alignSelf:"center",
    textAlign:"center"
  },
  header: {
    elevation: 0,
    backgroundColor: 'transparent',
    alignItems: "center",
    justifyContent: "center",
    width:deviceWidth,
    paddingHorizontal:0,
    paddingVertical:0,
  
  },
  
  headview:{
    height:'100%',
    width:'100%',
    flexDirection:'row',
    borderBottomRightRadius:15,
    borderBottomLeftRadius:15,
    paddingHorizontal:10,
    justifyContent:'space-between',
    backgroundColor:'#EFDF79'
  },
  text:{
      alignSelf:"center"
  },
  text2:{
    alignSelf:"center",
    marginTop:50
}
,mapShow:{
    height: 300,
    margin: 20,
    borderWidth: 1,
    padding: 10,
    borderColor:'c#EFDF79'
  }
});
export default TrackYourDelivery