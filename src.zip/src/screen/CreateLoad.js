import React,{useState} from 'react'
import { View,Button, Text,TouchableOpacity,TextInput,SafeAreaView, StyleSheet, ScrollView } from 'react-native'
import AppConstance,{deviceHeight,deviceWidth} from "../constance/AppConstance"
import DatePicker from 'react-native-date-picker'
import { Appbar } from "react-native-paper";
import Ionicons from 'react-native-vector-icons/dist/Ionicons';


const CreateLoad = ({navigation}) => {
  const [date, setDate] = useState(new Date())
  const [pickuptimeopen, setpickuptimeopen] = useState(false)
  const [dropofftimeopen, setdropofftimeopen] = useState(false) 
  const [pickuptimedate, setpickuptimedate] = useState('')
  const [dropofftimedate, setdropofftimedate] = useState(new Date())




  return (
    <SafeAreaView style={styles.container}>
 <DatePicker
        modal
        open={pickuptimeopen}
        date={new Date()}

        onConfirm={(date) => {

          setpickuptimeopen(false)
          setpickuptimedate(date)
        }}
        onCancel={() => {
          setpickuptimeopen(false)
        }}
      />
       <DatePicker
        modal
        open={dropofftimeopen}
        date={dropofftimedate}
        onConfirm={(date) => {
          setdropofftimeopen(false)
          setdropofftimedate(date)
        }}
        onCancel={() => {
          setdropofftimeopen(false)
          // setOpen(false)
        }}
      />
        <Appbar.Header style={styles.header}>

        <View style={styles.headview}>
          <View style={{justifyContent:"center"}}>
            <Ionicons name='chevron-back' onPress={()=> {navigation.goBack()}} color={'grey'} style={{alignSelf:'center'}} size={25}/>
            </View>
          <Text style={{color:"black",fontSize:16,alignSelf:'center'}}>Create a Load</Text>
          <View>
            </View>
        </View>

        </Appbar.Header>

      <ScrollView style={{paddingHorizontal:15}}>

      
    <View
      style={{  marginTop:20,height:50,flexDirection:'row',borderWidth: 1,
      borderRadius:15,
      borderColor:'#EFDF79',alignSelf:'center',
      backgroundColor:"white", justifyContent:'space-between', width:'90%',}}
    >

    <TextInput   
    style={{    height: '100%',
    width:"80%",
    alignSelf:"center",
    paddingHorizontal:15,
    }}
    placeholder="Pick-Up Location"
    placeholderTextColor={'grey'}
    />

    <TouchableOpacity style={{borderLeftWidth:1,borderColor:'#EFDF79',width:'15%', justifyContent:'center'}}>
      <Ionicons name='ios-location' style={{alignSelf:'center'}} size={22} color={'red'} />
    </TouchableOpacity>

</View>



<View
style={{  marginTop:20,height:50,flexDirection:'row',borderWidth: 1,
borderRadius:15,
borderColor:'#EFDF79',alignSelf:'center',
backgroundColor:"white", justifyContent:'space-between', width:'90%',}}

>
<TextInput   
style={{    height: '100%',
width:"80%",
alignSelf:"center",
paddingHorizontal:15,
}}
placeholder="Drop-Off Location"
placeholderTextColor={'grey'}
/>
<TouchableOpacity style={{borderLeftWidth:1,borderColor:'#EFDF79',width:'15%', justifyContent:'center'}}>
  <Ionicons name='ios-location' style={{alignSelf:'center'}} size={22} color={'red'} />
</TouchableOpacity>

</View>



<View style={{marginTop:15,width:'90%',alignSelf:'center', height:50}}>
<TextInput   
style={styles.input}
placeholder="Load Description"
editable={false}
placeholderTextColor={'grey'}
/>
</View>

<View style={{marginTop:15,width:'90%',alignSelf:'center',  height:50}}>

<TextInput   
style={styles.input}
placeholder="Dock Number"
placeholderTextColor={'grey'}
/>
</View>

<View
      style={{  marginTop:20,height:50,flexDirection:'row',borderWidth: 1,
      borderRadius:15,
      borderColor:'#EFDF79',alignSelf:'center',
      backgroundColor:"white", justifyContent:'space-between', width:'90%',}}
    >

    <TextInput   
    style={{    height: '100%',
    width:"80%",
    alignSelf:"center",
    paddingHorizontal:15,
    }}
    value={pickuptimedate}
    placeholder="Pick-up Time"
    placeholderTextColor={'grey'}
    />

    <TouchableOpacity 
        onPress={()=> {setpickuptimeopen(true)}}

    style={{borderLeftWidth:1,borderColor:'#EFDF79',width:'15%', justifyContent:'center'}}>
      <Ionicons name='md-time-outline' style={{alignSelf:'center'}} size={22} color={'grey'} />
    </TouchableOpacity>

</View>

<View
      style={{  marginTop:20,height:50,flexDirection:'row',borderWidth: 1,
      borderRadius:15,
      borderColor:'#EFDF79',alignSelf:'center',
      backgroundColor:"white", justifyContent:'space-between', width:'90%',}}
    >

    <TextInput   
    style={{    height: '100%',
    width:"80%",
    alignSelf:"center",
    paddingHorizontal:15,
    }}
    value={dropofftimedate}
    placeholder="Drop-off Time"
    placeholderTextColor={'grey'}
    />

    <TouchableOpacity style={{borderLeftWidth:1,borderColor:'#EFDF79',width:'15%', justifyContent:'center'}}
    onPress={()=> {setdropofftimeopen(true)}}
    >
      <Ionicons name='md-time-outline' style={{alignSelf:'center'}} size={22} color={'grey'} />
    </TouchableOpacity>

</View>

<View style={{marginTop:15 ,width:'90%',alignSelf:'center',  height:50}}>

<TextInput   
style={styles.input}
placeholder="Confirmed Pricing"
editable={false}
placeholderTextColor={'grey'}
/>
</View>

<TouchableOpacity
style={styles.brnAccept}
onPress={() => navigation.navigate('welcome')}
>
<Text   
style={{alignSelf:'center'}}>Create</Text>
</TouchableOpacity>
      </ScrollView>

</SafeAreaView>
  )
}


  const styles = StyleSheet.create({
    container: {
        flex: 1,
      //   justifyContent: center,
      height:deviceHeight,
      width:deviceWidth,
      },
      brnAccept: {
        height: 50,
        width:'60%',
        marginTop:20,
        borderWidth: 1,
        justifyContent:'center',
        borderColor:'#EFDF79',
        alignSelf:"center",
        textAlign:"center",
        borderRadius:10,
        backgroundColor:"#EFDF79"
      },
    input: {
      height: '100%',
      width:"100%",
      alignSelf:"center",
      paddingHorizontal:15,
      borderWidth: 1,
      borderRadius:15,
      borderColor:'#EFDF79',
      backgroundColor:"white",
      
    },
    header: {
      elevation: 0,
      backgroundColor: 'transparent',
      alignItems: "center",
      justifyContent: "center",
      width:deviceWidth,
      paddingHorizontal:0,
      paddingVertical:0,
    
    },
    
    headview:{
      height:'100%',
      width:'100%',
      flexDirection:'row',
      borderBottomRightRadius:15,
      borderBottomLeftRadius:15,
      paddingHorizontal:10,
      justifyContent:'space-between',
      backgroundColor:'#EFDF79'
    },
    text:{
        alignSelf:"center"
    }
  });

export default CreateLoad